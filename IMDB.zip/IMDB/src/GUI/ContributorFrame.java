package GUI;

import Users.User;

public class ContributorFrame extends LoggedInFrame{
    public ContributorFrame(User user) {
        super(user);
    }
}
