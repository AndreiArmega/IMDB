package GUI;

import Users.User;

public class RegularFrame extends LoggedInFrame{
    public RegularFrame(User user) {
        super(user);
    }
}
