package GUI;

import Users.User;

public class AdminFrame extends LoggedInFrame{
    public AdminFrame(User user) {
        super(user);
    }
}
