package RequestTree;

public interface RequestManager {
    void createRequest(Request request);

    void removeRequest(Request request);
}
