package ProductionTree;

public enum Genre {
    ACTION,
    ADVENTURE,
    COMEDY,
    DRAMA,
    HORROR,
    SF,
    FANTASY,
    ROMANCE,
    MYSTERY,
    THRILLER,
    CRIME,
    BIOGRAPHY,
    WAR,
}
