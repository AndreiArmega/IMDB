package ProductionTree;

public class FilmPairNameType {
    private String name;
    private Object type;


    public FilmPairNameType(String name, Object type) {
        this.name = name;
        this.type = type;

    }

    public String getName() {
        return name;
    }

    public Object getType() {
        return type;
    }

}
