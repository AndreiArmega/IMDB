package Users;

public enum AccountType {
    REGULAR,
    CONTRIBUTOR,
    ADMIN
}

