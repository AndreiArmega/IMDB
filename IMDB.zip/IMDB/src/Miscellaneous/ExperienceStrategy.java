package Miscellaneous;

public interface ExperienceStrategy {
    public int calculateExperience();

}
