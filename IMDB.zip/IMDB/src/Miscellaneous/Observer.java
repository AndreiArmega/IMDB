package Miscellaneous;

public interface Observer {
    void update(String notification);
}
