package Miscellaneous;

public class RequestExperienceStrategy implements ExperienceStrategy {
    @Override
    public int calculateExperience() {

        return 10;
    }
    public static int calcEXP()
    {
        return 10;
    }
}